// CS370
// Lab21 - DirtBall

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <SOIL/SOIL.h>

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* vertexFile = "dirtvert.vs";
GLchar* fragmentFile = "dirtfrag.fs";

// Texture globals
#define NO_TEXTURES 3
#define BALL_UNIT 0
#define DIRT_UNIT 1
#define BALL 0
#define BLANK 1
#define DIRT 2
#define X 0
#define Y 1
#define Z 2
#define DEG2RAD (3.14159/180.0)

GLuint tex_ids[NO_TEXTURES];
char texture_files[NO_TEXTURES][20] = {"Basketball.bmp","blank.png","dirt.png"};

// Shader objects
GLuint dirtProg;
GLint texSampler[NO_TEXTURES];

// Scene globals
GLfloat theta[] = {30.0f,45.0f,0.0f};
int startx = 0;
int starty = 0;
bool add_dirt = false;

// Global camera vectors
GLfloat eye[3] = {1.0f,1.0f,1.0f};
GLfloat at[3] = {0.0f,0.0f,0.0f};
GLfloat up[3] = {0.0f,1.0f,0.0f};

// Global spherical coord values
GLfloat azimuth = 45.0f;
GLfloat daz = 2.0f;
GLfloat elevation = 60.0f;
GLfloat del = 2.0f;
GLfloat radius = 1.0f;

// Global screen dimensions
GLint ww,hh;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void reshape(int w, int h);
void mousefunc(int button, int state, int x, int y);
void mousemove(int x, int y);
bool load_textures();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to image size
	glutInitWindowSize(512,512);

	// Create window
	glutCreateWindow("Dirty Basketball");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutReshapeFunc(reshape);
	glutMouseFunc(mousefunc);
	glutMotionFunc(mousemove);

	// Compute initial cartesian camera position
	eye[X] = (GLfloat)(radius*sin(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));
	eye[Y] = (GLfloat)(radius*cos(elevation*DEG2RAD));
	eye[Z] = (GLfloat)(radius*cos(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Load textures
	if (!load_textures())
	{
		printf("Failed to load textures!\n");
		exit(0);
	}

	// Load shader programs
	dirtProg = load_shaders(vertexFile, fragmentFile);

	// TODO: Associate shader sampler variables with corresponding texture unit

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// Adjust viewing volume (orthographic)
	GLfloat xratio = 1.0f;
	GLfloat yratio = 1.0f;
	// If taller than wide adjust y
	if (ww <= hh)
	{
		yratio = (GLfloat)hh / (GLfloat)ww;
	}
	// If wider than tall adjust x
	else if (hh <= ww)
	{
		xratio = (GLfloat)ww / (GLfloat)hh;
	}
	glOrtho(-2.0f*xratio, 2.0f*xratio, -2.0f*yratio, 2.0f*yratio, -2.0f, 2.0f);

	// Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(eye[X], eye[Y], eye[Z], at[X], at[Y], at[Z], up[X], up[Y], up[Z]);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// TODO: Activate shader program

	// TODO: Associate BALL with texture unit 0 (BALL_UNIT)

	// TODO: Associate DIRT with texture unit 1 (DIRT_UNIT)

	if (!add_dirt)
	{
		// No dirt - bind BLANK texture
	}
	else
	{
		// Dirt - bind DIRT texture
	}

	// TODO: Draw multitextured surface
	glPushMatrix();
		glBegin(GL_POLYGON);
			glColor3f(1.0f,1.0f,1.0f);
			glVertex3f(-1.0f,0.0f,1.0f);

			glVertex3f(1.0f,0.0f,1.0f);

			glVertex3f(1.0f,0.0f,-1.0f);

			glVertex3f(-1.0f,0.0f,-1.0f);
		glEnd();
	glPopMatrix();
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// <space> toggles dirt
	if (key == ' ')
	{
		add_dirt = !add_dirt;
	}

	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Mouse callback
void mousefunc(int button, int state, int x, int y)
{
	// Rotate about x and y axes for left button
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		startx = x;
		starty = y;
	}
}

// Mouse move callback
void mousemove(int x, int y)
{
	// Adjust x and y rotation angles
	elevation += (y - starty);
	if (elevation > 179.8)
	{
		elevation = 179.8;
	}
	else if (elevation < 0.0)
	{
		elevation = 0.2;
	}

	azimuth += (x - startx);
	if (azimuth > 360.0)
	{
		azimuth -= 360.0;
	}
	else if (azimuth < 0.0)
	{
		azimuth += 360.0;
	}

	// Compute cartesian camera position
	eye[X] = (GLfloat)(radius*sin(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));
	eye[Y] = (GLfloat)(radius*cos(elevation*DEG2RAD));
	eye[Z] = (GLfloat)(radius*cos(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));

	// Update mouse reference position
	startx = x;
	starty = y;

	// Redraw display
	glutPostRedisplay();
}

// Routine to load textures using SOIL
bool load_textures()
{
	// Load object textures normally
	for (int i=0; i < NO_TEXTURES; i++)
	{
		// Load bitmaps
		tex_ids[i] = SOIL_load_OGL_texture(texture_files[i],SOIL_LOAD_AUTO,SOIL_CREATE_NEW_ID,SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y);


		// Set texture properties if successfully loaded
		if (tex_ids[i] != 0)
		{
			// Set scaling filters
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);

			// Set wrapping modes
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
		}
		// Otherwise texture failed to load
		else
		{
			return false;
		}
	}
	return true;
}

// Reshape callback
void reshape(int w, int h)
{
	// Set new screen extents
	glViewport(0, 0, w, h);
	
	// Store new extents
	ww = w;
	hh = h;
}
