// CS370 - Fall 2016
// Lab22 - BumpBall

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <SOIL/SOIL.h>

// Shader file utility functions
#include "shaderutils.h"
#include "lighting.h"

// Multitexture sphere source code
#include "sphere.h"

// Shader files
GLchar* bumpVertexFile = "bumpvert.vs";
GLchar* bumpFragmentFile = "bumpfrag.fs";
GLchar* texVertexFile = "texvert.vs";
GLchar* texFragmentFile = "texfrag.fs";

// Texture globals
#define NO_TEXTURES 2
#define BALL_UNIT 0
#define NORMAL_UNIT 1
#define BALL 0
#define NORMAL 1
#define X 0
#define Y 1
#define Z 2
#define DEG2RAD (3.14159/180.0)

GLuint tex_ids[NO_TEXTURES];
char texture_files[NO_TEXTURES][20] = {"Basketball.bmp","dimple_normal.bmp"};

// Shader objects
GLuint bumpProg;
GLuint texProg;
GLint bumpSampler[NO_TEXTURES];
GLint texSampler;

// TODO: Global tangent parameter

// Scene globals
GLfloat theta[] = { 30.0f,45.0f,0.0f };
GLfloat light0_pos[] = {2.0f,2.0f,2.0f,1.0f};
GLfloat light0_dir[] = {-1.0f,-1.0f,-1.0f};
int startx = 0;
int starty = 0;
bool use_bump = false;

// Global camera vectors
GLfloat eye[3] = {1.0f,1.0f,1.0f};
GLfloat at[3] = {0.0f,0.0f,0.0f};
GLfloat up[3] = {0.0f,1.0f,0.0f};

// Global spherical coord values
GLfloat azimuth = 45.0f;
GLfloat daz = 2.0f;
GLfloat elevation = 60.0f;
GLfloat del = 2.0f;
GLfloat radius = 1.0f;

// Global screen dimensions
GLfloat ww,hh;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void reshape(int w, int h);
void mousefunc(int button, int state, int x, int y);
void mousemove(int x, int y);
bool load_textures();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to image size
	glutInitWindowSize(512,512);

	// Create window
	glutCreateWindow("Bump Basketball");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutReshapeFunc(reshape);
	glutMouseFunc(mousefunc);
	glutMotionFunc(mousemove);

	// Compute initial cartesian camera position
	eye[X] = (GLfloat)(radius*sin(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));
	eye[Y] = (GLfloat)(radius*cos(elevation*DEG2RAD));
	eye[Z] = (GLfloat)(radius*cos(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Ambient light
	GLfloat background[] = {1.0f,1.0f,1.0f,1.0f};
	set_AmbientLight(background);

	// Load textures
	if (!load_textures())
	{
		printf("Failed to load textures!\n");
		exit(0);
	}

	// Load shader programs
	bumpProg = load_shaders(bumpVertexFile, bumpFragmentFile);
	texProg = load_shaders(texVertexFile, texFragmentFile);

	// Associate shader sampler variables
	bumpSampler[BALL_UNIT] = glGetUniformLocation(bumpProg,"colorMap");
	bumpSampler[NORMAL_UNIT] = glGetUniformLocation(bumpProg,"normalMap");
	texSampler = glGetUniformLocation(texProg,"texMap");

	// TODO: Associate tangent shader variable

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// Adjust viewing volume (orthographic)
	GLfloat xratio = 1.0f;
	GLfloat yratio = 1.0f;
	// If taller than wide adjust y
	if (ww <= hh)
	{
		yratio = (GLfloat)hh / (GLfloat)ww;
	}
	// If wider than tall adjust x
	else if (hh <= ww)
	{
		xratio = (GLfloat)ww / (GLfloat)hh;
	}
	glOrtho(-2.0f*xratio, 2.0f*xratio, -2.0f*yratio, 2.0f*yratio, -2.0f, 2.0f);

	// Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(eye[X], eye[Y], eye[Z], at[X], at[Y], at[Z], up[X], up[Y], up[Z]);

	// Render scene without shadows
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// Enable lighting
	set_SpotLight(GL_LIGHT0, &white_light,light0_pos,light0_dir,90.0f,0.0f);

	if (use_bump)
	{
		// Activate bump map shader
		glUseProgram(bumpProg);
			
		// Associate BALL with texture unit 0
		glUniform1i(bumpSampler[BALL_UNIT],BALL);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D,tex_ids[BALL]);

		// Associate NORMAL with texture unit 1
		glUniform1i(bumpSampler[NORMAL],NORMAL);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D,tex_ids[NORMAL]);
	}
	else
	{
		// Activate standard texture shader
		glUseProgram(texProg);
				
		// Associate BALL with texture unit 0
		glUniform1i(texSampler,BALL);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D,tex_ids[BALL]);
	}

	// Draw bump mapped sphere
	glPushMatrix();
		glRotatef(theta[0], 1.0f, 0.0f, 0.0f);
		glRotatef(theta[1], 0.0f, 1.0f, 0.0f);
		mySphere2(use_bump, tangParam);
	glPopMatrix();
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// <space> toggles bump mapping
	if (key == ' ')
	{
		use_bump = !use_bump;
	}
	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Mouse callback
void mousefunc(int button, int state, int x, int y)
{
	// Rotate about x and y axes for left button
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		startx = x;
		starty = y;
	}
}

// Mouse move callback
void mousemove(int x, int y)
{
	// Adjust x rotation angle
	theta[0] += (y - starty);
	if (theta[0] > 360.0)
	{
		theta[0] -= 360.0f;
	}
	else if (theta[0] < 0.0f)
	{
		theta[0] += 360.0f;
	}

	// Adjust y rotation angle
	theta[1] += (x - startx);
	if (theta[1] > 360.0)
	{
		theta[1] -= 360.0f;
	}
	else if (theta[1] < 0.0f)
	{
		theta[1] += 360.0f;
	}

	// Update mouse position
	startx = x;
	starty = y;

	// Redraw display
	glutPostRedisplay();
}

// Routine to load textures using SOIL
bool load_textures()
{
	// Load object textures normally
	for (int i=0; i < NO_TEXTURES; i++)
	{
		// Load bitmaps
		tex_ids[i] = SOIL_load_OGL_texture(texture_files[i],SOIL_LOAD_AUTO,SOIL_CREATE_NEW_ID,SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y);


		// Set texture properties if successfully loaded
		if (tex_ids[i] != 0)
		{
			// Set scaling filters
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);

			// Set wrapping modes
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
		}
		// Otherwise texture failed to load
		else
		{
			return false;
		}
	}
	return true;
}

// Reshape callback
void reshape(int w, int h)
{
	// Set new screen extents
	glViewport(0, 0, w, h);
	
	// Store new extents
	ww = w;
	hh = h;
}
