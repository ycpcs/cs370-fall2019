// CS370
// Lab10 - BasicGLSL

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>

// Shader file utility functions
#include "shaderutils.h"

#define X 0
#define Y 1
#define Z 2
#define DEG_PER_SEC (360.0f/60.0f)
#define ANG_STEP 0.5f

// Shader files
GLchar* vertexFile = "basicvert.vs";
GLchar* fragmentFile = "basicfrag.fs";

// Shader objects
GLuint shaderProg;

// Global camera vectors
GLfloat eye[3] = { 1.0f,1.0f,1.0f };
GLfloat at[3] = { 0.0f,0.0f,0.0f };
GLfloat up[3] = { 0.0f,1.0f,0.0f };

// Global screen extents
GLint ww;
GLint hh;

// Global variables
GLfloat theta = 0.0f;
GLint time = 0;
GLint lasttime = 0;
GLint fps = 30;
GLfloat rpm = 10.0f;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void reshape(int w, int h);
void idlefunc();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to image size
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Basic GLSL");

#ifndef OSX
	// TODO: Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW

#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutReshapeFunc(reshape);
	glutIdleFunc(idlefunc);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Load shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);

	// TODO: Activate shader program

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set 3D projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	GLfloat xratio = 1.0f;
	GLfloat yratio = 1.0f;
	// Taller than wide so scale height
	if (ww <= hh)
	{
		yratio = (GLfloat)ww / (GLfloat)hh;
	}
	// Wider than tall so scale width
	else
	{
		xratio = (GLfloat)hh / (GLfloat)ww;
	}
	glOrtho(-3.0f*xratio, 3.0*xratio, -3.0f*yratio, 3.0f*yratio, -3.0f, 3.0f);

	// Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(eye[X], eye[Y], eye[Z], at[X], at[Y], at[Z], up[X], up[Y], up[Z]);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// Draw cube
	glPushMatrix();
	glTranslatef(0.0f, 0.0f, 0.0f);
		glRotatef(theta,0.0f,1.0f,0.0f);
		glScalef(1.0f, 1.0f, 1.0f);
		glColor3f(1.0f,1.0f,0.0f);
		glutSolidCube(1.0);
	
		// Draw edges
		glColor3f(0.0f,0.0f,0.0f);
		glutWireCube(1.0);
	glPopMatrix();
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Reshape callback
void reshape(int w, int h)
{
	// Set new screen extents
	glViewport(0,0,w,h);

	// Store new extents
	ww = w;
	hh = h;
}

// Idle callback
void idlefunc()
{
	// Get total elapsed time
	time = glutGet(GLUT_ELAPSED_TIME);
	
	// Update if past desired interval
	if (time-lasttime > 1000.0f/fps)
	{
		// Compute angular change for desired cube rpm
		theta += 6.0f*rpm*(time-lasttime)/1000.0f;
		
		// Completed full revolution
		if (theta > 360.0f)
		{
			theta -= 360.0f;
		}

		// Update lasttime (reset timer)
		lasttime = time;

		// Render scene
		glutPostRedisplay();
	}		
}