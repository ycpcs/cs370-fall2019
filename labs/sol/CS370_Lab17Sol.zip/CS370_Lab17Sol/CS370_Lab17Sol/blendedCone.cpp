// CS370
// Lab17 - BlendedCone

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lighting.h"
#include "materials.h"

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* vertexFile = "lightvert.vs";
GLchar* fragmentFile = "lightfrag.fs";

// Shader objects
GLuint shaderProg;
GLuint numLights_param;

#define SPHERE_STEP 0.25f
#define SPHERE_MAX 2.0f
#define SPHERE_MIN (-0.2f)
#define TORUS_STEP 3.0f
#define LIGHT_STEP 2.0f
#define X 0
#define Y 1
#define Z 2

// Light0 (directional) Parameters
GLfloat light0_pos[] = {0.0f,2.0f,2.0f,1.0f};
GLfloat background[] = {0.2f,0.2f,0.2f,1.0f};

// Global object initial positions
GLfloat sphere_pos[3] = {0.0f,0.0f,-0.2f};
GLfloat torus_pos[3] = {0.0f,-1.25f,1.5f};

// TODO: Global quadric
GLUquadricObj *quadric;

// Global animation variables
GLint time = 0;
GLint lasttime = 0;
GLint fps = 30;
GLfloat light_theta = 0.0f;
bool rot_light = false;
bool bounce_sphere = false;
int sphere_dir = 1;
bool roll_torus = false;
GLfloat torus_theta = 0.0f;
GLint numLights = 1;

// Global camera vectors
GLfloat eye[3] = {0.0f,0.0f,4.0f};
GLfloat at[3] = {0.0f,0.0f,0.0f};
GLfloat up[3] = {0.0f,1.0f,0.0f};

// Global screen dimensions
GLint ww,hh;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void idlefunc();
void reshape(int w, int h);

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Blended Cone");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutIdleFunc(idlefunc);
	glutReshapeFunc(reshape);

	// Set background color to black
	glClearColor(0.0f,0.0f,0.0f,0.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Set ambient light
	set_AmbientLight(background);

	// TODO: Enable alpha blending
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// TODO: Create quadric
	quadric = gluNewQuadric();
	gluQuadricDrawStyle(quadric, GLU_FILL);
	gluQuadricNormals(quadric, GLU_SMOOTH);

	// Load shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);
	// Associate num_lights parameter
	numLights_param = glGetUniformLocation(shaderProg,"numLights");

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// Adjust viewing volume (orthographic)
	GLfloat xratio = 1.0f;
	GLfloat yratio = 1.0f;
	// If taller than wide adjust y
	if (ww <= hh)
	{
		yratio = (GLfloat)hh / (GLfloat)ww;
	}
	// If wider than tall adjust x
	else if (hh <= ww)
	{
		xratio = (GLfloat)ww / (GLfloat)hh;
	}
	glFrustum(-4.0f*xratio,4.0f*xratio,-4.0f*yratio,4.0f*yratio,2.0f,6.0f);

	// Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(eye[X], eye[Y], eye[Z], at[X], at[Y], at[Z], up[X], up[Y], up[Z]);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// Set number of lights
	glUseProgram(shaderProg);
	glUniform1i(numLights_param, numLights);

	// Rotate light
	glPushMatrix();
		glRotatef(light_theta, 0.0f, 1.0f, 0.0f);
		set_PointLight(GL_LIGHT0, &white_light, light0_pos);
	glPopMatrix();

	// Render white plastic table
	glPushMatrix();
		set_material(GL_FRONT_AND_BACK,&white_plastic);
		glBegin(GL_POLYGON);
			glVertex3f(-3.0f,-2.0f,-3.0f);
			glVertex3f(3.0f,-2.0f,-3.0f);
			glVertex3f(3.0f,-2.0f,3.0f);
			glVertex3f(-3.0f,-2.0f,3.0f);
		glEnd();
	glPopMatrix();

	// TODO: Render brass sphere
	glPushMatrix();
	set_material(GL_FRONT_AND_BACK, &brass);
	glTranslatef(sphere_pos[0], sphere_pos[1], sphere_pos[2]);
	gluSphere(quadric, 1.0, 90, 90);
	glPopMatrix();

	// TODO: Render brass torus
	glPushMatrix();
	set_material(GL_FRONT_AND_BACK, &brass);
	glRotatef(torus_theta, 0.0f, 1.0f, 0.0f);
	glTranslatef(torus_pos[0], torus_pos[1], torus_pos[2]);
	glutSolidTorus(0.25, 0.5, 20, 20);
	glPopMatrix();

	// TODO: Render red acrylic cylinder toggling depth mask
	glPushMatrix();
	set_material(GL_FRONT_AND_BACK, &red_acrylic);
	glDepthMask(GL_FALSE);
	glTranslatef(0.0f, -2.0f, 0.0f);
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	gluCylinder(quadric, 1.0, 0.5, 1.0, 90, 90);
	glDepthMask(GL_TRUE);
	glPopMatrix();
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// <space> toggles light rotation
	if (key == 'l' || key == 'L')
	{
		rot_light = !rot_light;
	}

	// b toggles bouncing sphere
	if (key == 'b' || key == 'B')
	{
		bounce_sphere = !bounce_sphere;
	}

	// r toggles rolling torus
	if (key == 'r' || key == 'R')
	{
		roll_torus = !roll_torus;
	}

	// + - changes background light
	if (key == '=' || key == '+')
	{
		for(int i=0; i<3; i++)
		{
			background[i] += 0.1f;
			if (background[i] > 1.0f)
			{
				background[i] = 1.0f;
			}
		}
		set_AmbientLight(background);

	}
	else if (key == '-' || key == '_')
	{
		for(int i=0; i<3; i++)
		{
			background[i] -= 0.1f;
			if (background[i] < 0.0f)
			{
				background[i] = 0.0f;
			}
		}
		set_AmbientLight(background);
	}


	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Idle callback
void idlefunc()
{
	if (bounce_sphere || roll_torus || rot_light)
	{
		// Get total elapsed time
		time = glutGet(GLUT_ELAPSED_TIME);

		// Update if past desired interval
		if (time-lasttime > 1000.0f/fps)
		{
			// TODO: Bounce sphere
			if (bounce_sphere)
			{
				sphere_pos[1] += sphere_dir*SPHERE_STEP;
				if ((sphere_pos[1] > SPHERE_MAX) || (sphere_pos[1] < SPHERE_MIN))
				{
					sphere_dir *= -1;
				}

			}
			
			// TODO: Roll torus
			if (roll_torus)
			{
				torus_theta += TORUS_STEP;
				if (torus_theta > 360.0f)
				{
					torus_theta -= 360.0f;
				}

			}
			
			// Rotate light
			if (rot_light)
			{
				light_theta += LIGHT_STEP;
				if (light_theta > 360.0f)
				{
					light_theta -= 360.0f;
				}
			}

			// Update lasttime (reset timer)
			lasttime = time;

			// Render scene
			glutPostRedisplay();
		}
	}
}

// Reshape callback
void reshape(int w, int h)
{
	// Set new screen extents
	glViewport(0, 0, w, h);

	// Store new extents
	ww = w;
	hh = h;
}
