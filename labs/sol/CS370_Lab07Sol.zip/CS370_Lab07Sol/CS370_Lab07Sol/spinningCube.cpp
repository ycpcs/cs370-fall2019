// CS370
// Lab07 - SpinningCube

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* vertexFile = "basicvert.vs";
GLchar* fragmentFile = "basicfrag.fs";

// Shader objects
GLuint shaderProg;

// TODO: Cube vertices
GLfloat cube[][3] = {{-1.0f,-1.0f,-1.0f},{1.0f,-1.0f,-1.0f},{1.0f,-1.0f,1.0f},
                     {-1.0f,-1.0f,1.0f},{-1.0f,1.0f,-1.0f},{1.0f,1.0f,-1.0f},
                     {1.0f,1.0f,1.0f},{-1.0f,1.0f,1.0f}};

// Vertex colors
GLfloat colors[][3] = {{0.0f,0.0f,0.0f},{1.0f,0.0f,0.0f},{1.0f,0.0f,1.0f},
                       {0.0f,0.0f,1.0f},{0.0f,1.0f,0.0f},{1.0f,1.0f,0.0f},
                       {1.0f,1.0f,1.0f},{0.0f,1.0f,1.0f}};

// Global rotation values
GLfloat theta = 0.0f;
GLfloat dtheta = 0.1f;

// Global screen dimensions
GLint ww,hh;

// Animation flag
GLint anim = false;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void idlefunc();
void reshape(int w, int h);
void colorcube();
void quad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[],
	      GLfloat c1[], GLfloat c2[], GLfloat c3[], GLfloat c4[]);

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// TODO: Initialize the window with double buffering and RGB colors *and depth buffer*
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Spinning Cube");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// TODO: Define callbacks *including reshape callback*
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutIdleFunc(idlefunc);
	glutReshapeFunc(reshape);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// TODO: Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Load and activate shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);
	glUseProgram(shaderProg);

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// TODO: Reset background *and depth buffer*
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// TODO: Set projection matrix for anisotropic scaling
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// Set orthographic viewing volume isotropic
	glOrtho(-2.0f, 2.0f, -2.0f, 2.0f, -2.0f, 2.0f);	

	// Set orthographic viewing volume anisotropic
	GLfloat xratio = 1.0f;
	GLfloat yratio = 1.0f;
	// If taller than wide adjust y
	if (ww <= hh)
	{
		yratio = (GLfloat)hh / (GLfloat)ww;
	}
	// If wider than tall adjust x
	else if (hh <= ww)
	{
		xratio = (GLfloat)ww / (GLfloat)hh;
	}
	glOrtho(-2.0f*xratio, 2.0f*xratio, -2.0f*yratio, 2.0f*yratio, -2.0f, 2.0f);

	
	// Set modelview matrix with default camera
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// TODO: Instance transformation to rotate cube
	glTranslatef(0.0f,0.0f,0.0f);
	glRotatef(theta, 1.0f, 1.0f, 1.0f);
	glScalef(1.0f,1.0f,1.0f);
	
	// TODO: Draw cube
	colorcube();

}

// Reshape callback
void reshape(int w, int h)
{
	// Set new screen extents
	glViewport(0, 0, w, h);

	// TODO: Store new extents
	ww = w;
	hh = h;
}

// Routine to draw cube
void colorcube()
{
	// TODO: Top face
	quad(cube[4], cube[7], cube[6], cube[5], colors[4], colors[7], colors[6], colors[5]);

	// TODO: Bottom face
	quad(cube[0], cube[1], cube[2], cube[3], colors[0], colors[1], colors[2], colors[3]);

	// TODO: Left face
	quad(cube[0], cube[3], cube[7], cube[4], colors[0], colors[3], colors[7], colors[4]);

	// TODO: Right face
	quad(cube[1], cube[5], cube[6], cube[2], colors[1], colors[5], colors[6], colors[2]);

	// TODO: Front face
	quad(cube[2], cube[6], cube[7], cube[3], colors[2], colors[6], colors[7], colors[3]);

	// TODO: Back face
	quad(cube[0], cube[4], cube[5], cube[1], colors[0], colors[4], colors[5], colors[1]);
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{

	// <space> toggles animation
	if (key == ' ')
	{
		anim = !anim;
	}
	// <esc> quits
	else if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Idle callback
void idlefunc()
{
	// Animation code
	if (anim)
	{
		theta += dtheta;
		if (theta > 360.0f)
		{
			theta -= 360.0f;
		}

		// Redraw screen
		glutPostRedisplay();
	}
}

// Routine to draw (outlined) quadrilateral face
void quad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[],
	      GLfloat c1[], GLfloat c2[], GLfloat c3[], GLfloat c4[])
{
	// Draw face
	glBegin(GL_POLYGON);
		glColor3fv(c1);
		glVertex3fv(v1);
		glColor3fv(c2);
		glVertex3fv(v2);
		glColor3fv(c3);
		glVertex3fv(v3);
		glColor3fv(c4);
		glVertex3fv(v4);
	glEnd();

	// Draw outline
	glColor3f(0.0f,0.0f,0.0f);
	glBegin(GL_LINE_LOOP);
		glVertex3fv(v1);
		glVertex3fv(v2);
		glVertex3fv(v3);
		glVertex3fv(v4);
	glEnd();
}
