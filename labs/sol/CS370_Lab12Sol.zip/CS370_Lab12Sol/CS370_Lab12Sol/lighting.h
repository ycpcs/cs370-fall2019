// Structure for lighting coefficients
struct LightType {
	GLfloat ambient[4];
	GLfloat diffuse[4];
	GLfloat specular[4];
};

// TODO: Lighting properties for basic white light
LightType white_light = { { 0.0f, 0.0f, 0.0f, 1.0f },
{ 1.0f, 1.0f, 1.0f, 1.0f },
{ 1.0f, 1.0f, 1.0f, 1.0f } };

// Utility function to set light properties
void set_light(GLenum source, LightType *light)
{
	glLightfv(source,GL_AMBIENT,light->ambient);
	glLightfv(source,GL_DIFFUSE,light->diffuse);
	glLightfv(source,GL_SPECULAR,light->specular);
}