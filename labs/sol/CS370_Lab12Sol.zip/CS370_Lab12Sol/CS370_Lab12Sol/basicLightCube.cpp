// CS370
// Lab12 - BasicLightCube

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lighting.h"
#include "materials.h"

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* vertexFile = "lightvert.vs";
GLchar* fragmentFile = "lightfrag.fs";

// Shader objects
GLuint shaderProg;
GLuint numLights_param;
GLint numLights = 1;

// Time based rendering parameters
#define DEG_PER_SEC (360.0f/60.0f)
#define FPS_INTERVAL 1000
GLint fps = 30;
GLfloat rpm = 10.0f;
GLint time = 0;
GLint lasttime = 0;

#define BRASS 1
#define CUBE 1
#define X 0
#define Y 1
#define Z 2

// Cube vertices
GLfloat cube[][3] = {{-1.0f,-1.0f,-1.0f},{1.0f,-1.0f,-1.0f},{1.0f,-1.0f,1.0f},
                     {-1.0f,-1.0f,1.0f},{-1.0f,1.0f,-1.0f},{1.0f,1.0f,-1.0f},
                     {1.0f,1.0f,1.0f},{-1.0f,1.0f,1.0f}};

// TODO: Cube surface normals
GLfloat normals[][3] = { { 0.0f, 1.0f, 0.0f },{ 0.0f, -1.0f, 0.0f },{ -1.0f, 0.0f, 0.0f },
{ 1.0f, 0.0f, 0.0f },{ 0.0f, 0.0f, 1.0f },{ 0.0f, 0.0f, -1.0f } };

// Cube rotation angle
GLfloat theta = 0.0f;
GLfloat dtheta = 0.1f;

// Global camera vectors
GLfloat eye[3] = {1.0f,1.0f,1.0f};
GLfloat at[3] = {0.0f,0.0f,0.0f};
GLfloat up[3] = {0.0f,1.0f,0.0f};

// Global screen dimensions
GLint ww,hh;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void idlefunc();
void reshape(int w, int h);
void colorcube();
void nquad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[], GLfloat n[]);
void create_lists();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Basic Light Cube");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutIdleFunc(idlefunc);
	glutReshapeFunc(reshape);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Create display list
	create_lists();

	// Load shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);
	// Associate num_lights parameter
	numLights_param = glGetUniformLocation(shaderProg, "numLights");
	// Activate shader program
	glUseProgram(shaderProg);

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// Adjust viewing volume (orthographic)
	GLfloat xratio = 1.0f;
	GLfloat yratio = 1.0f;
	// If taller than wide adjust y
	if (ww <= hh)
	{
		yratio = (GLfloat)hh / (GLfloat)ww;
	}
	// If wider than tall adjust x
	else if (hh <= ww)
	{
		xratio = (GLfloat)ww / (GLfloat)hh;
	}
	glOrtho(-3.0f*xratio, 3.0f*xratio, -3.0f*yratio, 3.0f*yratio, -3.0f, 3.0f);

	// Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(eye[X], eye[Y], eye[Z], at[X], at[Y], at[Z], up[X], up[Y], up[Z]);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// TODO: Set initial light source
	set_light(GL_LIGHT0, &white_light);

	// Set shader variable
	glUniform1i(numLights_param, numLights);
	// Render cube using display list
	glPushMatrix();
		// TODO: Set material to brass
		set_material(GL_FRONT_AND_BACK, &brass);
		glTranslatef(0.0f, 0.0f, 0.0f);
		glRotatef(theta,0.0f,1.0f,0.0f);
		glScalef(1.0f, 1.0f, 1.0f);
		glCallList(CUBE);
	glPopMatrix();
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Idle callback
void idlefunc()
{
	// Get total elapsed time
	time = glutGet(GLUT_ELAPSED_TIME);

	// Update if past desired interval
	if (time-lasttime > 1000.0f/fps)
	{
		// Compute angular change for desired rpm
		theta += 6.0f*rpm*(time-lasttime)/1000.0f;
		
		// Completed full revolution
		if (theta > 360.0f)
		{
			theta -= 360.0f;
		}

		// Update lasttime (reset timer)
		lasttime = time;

		// Render scene
		glutPostRedisplay();
	}
}

// Reshape callback
void reshape(int w, int h)
{
	// Set new screen extents
	glViewport(0, 0, w, h);

	// TODO: Store new extents
	ww = w;
	hh = h;
}

// Routine to draw cube
void colorcube()
{
	// Top face
	nquad(cube[4],cube[7],cube[6],cube[5],normals[0]);

	// Bottom face
	nquad(cube[0],cube[1],cube[2],cube[3],normals[1]);

	// Left face
	nquad(cube[0],cube[3],cube[7],cube[4],normals[2]);

	// Right face
	nquad(cube[1],cube[5],cube[6],cube[2],normals[3]);

	// Front face
	nquad(cube[2],cube[6],cube[7],cube[3],normals[4]);

	// Back face
	nquad(cube[0],cube[4],cube[5],cube[1],normals[5]);
}

// Routine to draw (outlined) quadrilateral face
void nquad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[], GLfloat n[])
{
	// TODO: Set face normal
	glNormal3fv(n);

	// Draw face
	glBegin(GL_POLYGON);
		glVertex3fv(v1);
		glVertex3fv(v2);
		glVertex3fv(v3);
		glVertex3fv(v4);
	glEnd();

	// Draw outline
	glColor3f(0.0f,0.0f,0.0f);
	glBegin(GL_LINE_LOOP);
		glVertex3fv(v1);
		glVertex3fv(v2);
		glVertex3fv(v3);
		glVertex3fv(v4);
	glEnd();
}

// Routine to create display lists
void create_lists()
{
	// Create colorcube display list
	glNewList(CUBE, GL_COMPILE);
		glPushAttrib(GL_CURRENT_BIT);
		colorcube();
		glPopAttrib();
	glEndList();
}

