// Train body

// Engineer's compartment

// Smoke stack

// Wheels

// Track

// Ties

// Blocks
